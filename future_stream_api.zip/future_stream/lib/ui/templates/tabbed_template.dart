import 'package:flutter/material.dart';

// Template: a reusable layout with an app bar, tabs, and one view per tab.
// It does not know anything about anime. It just arranges what you give it.
class TabbedTemplate extends StatelessWidget {
  final String title;
  final List<String> tabLabels; // names shown on the tabs
  final List<Widget> tabViews; // the screen for each tab

  const TabbedTemplate({
    super.key,
    required this.title,
    required this.tabLabels,
    required this.tabViews,
  });

  @override
  Widget build(BuildContext context) {
    // Turn each label (text) into a Tab widget.
    List<Widget> tabs = [];
    for (final label in tabLabels) {
      tabs.add(Tab(text: label));
    }

    return DefaultTabController(
      length: tabLabels.length,
      child: Scaffold(
        appBar: AppBar(
          title: Text(title),
          bottom: TabBar(tabs: tabs),
        ),
        body: TabBarView(children: tabViews),
      ),
    );
  }
}
