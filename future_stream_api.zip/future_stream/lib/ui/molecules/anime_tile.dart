import 'package:flutter/material.dart';
import '../../models/anime.dart';
import '../atoms/score_badge.dart';

// Molecule: one row in the Top Anime list.
class AnimeTile extends StatelessWidget {
  final Anime anime;
  final int rank; // 1, 2, 3 ...
  const AnimeTile({super.key, required this.anime, required this.rank});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      // Left side: the picture. If there is none, show a placeholder icon.
      // errorBuilder shows the icon too if the picture fails to download.
      leading: anime.image == null
          ? const Icon(Icons.image)
          : Image.network(
              anime.image!,
              width: 50,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.image),
            ),
      title: Text('#$rank ${anime.title}'),
      subtitle: Text(
        '${anime.genres.join(', ')}\n${anime.episodes ?? '?'} episodes',
      ),
      isThreeLine: true,
      // Right side: the score.
      trailing: ScoreBadge(score: anime.score),
    );
  }
}
