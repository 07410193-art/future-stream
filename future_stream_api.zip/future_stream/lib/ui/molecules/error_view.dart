import 'package:flutter/material.dart';

// Molecule: an error message, with an optional Retry button.
// If you pass onRetry, the button shows. If you leave it out, no button.
class ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  const ErrorView({super.key, required this.message, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(message, textAlign: TextAlign.center),
          // These two only appear when onRetry was given.
          if (onRetry != null) const SizedBox(height: 12),
          if (onRetry != null)
            ElevatedButton(onPressed: onRetry, child: const Text('Retry')),
        ],
      ),
    );
  }
}
