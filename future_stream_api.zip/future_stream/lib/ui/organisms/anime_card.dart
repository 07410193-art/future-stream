import 'package:flutter/material.dart';
import '../../models/anime.dart';
import '../atoms/genre_chip.dart';
import '../atoms/score_badge.dart';

// Organism: a big card showing one anime (used on the Live screen).
class AnimeCard extends StatelessWidget {
  final Anime anime;
  const AnimeCard({super.key, required this.anime});

  @override
  Widget build(BuildContext context) {
    // Turn the list of genre names into a list of GenreChip widgets.
    List<Widget> chips = [];
    for (final genre in anime.genres) {
      chips.add(GenreChip(label: genre));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Only show the picture if we have a URL for it.
          if (anime.image != null)
            Image.network(
              anime.image!,
              height: 250,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.image, size: 100),
            ),
          const SizedBox(height: 16),
          Text(
            anime.title,
            style: Theme.of(context).textTheme.titleLarge,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Wrap(spacing: 6, children: chips),
          const SizedBox(height: 12),
          Text('Episodes: ${anime.episodes ?? 'Ongoing'}'),
          ScoreBadge(score: anime.score),
          const SizedBox(height: 16),
          const Text('Updates every 5 seconds', style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
