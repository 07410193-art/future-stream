import 'package:flutter/material.dart';
import '../../models/anime.dart';
import '../molecules/anime_tile.dart';

// Organism: a scrolling list made of many AnimeTile rows.
class AnimeList extends StatelessWidget {
  final List<Anime> items;
  const AnimeList({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    // ListView.builder only builds the rows you can actually see,
    // so it stays fast even with a long list.
    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (context, index) {
        return AnimeTile(anime: items[index], rank: index + 1);
      },
    );
  }
}
