// Putting it together: two tabs, one Future screen and one Stream screen.
import 'package:flutter/material.dart';
import '../templates/tabbed_template.dart';
import 'anime_page.dart';
import 'live_anime_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const TabbedTemplate(
      title: 'Anime Live App',
      tabLabels: ['Top Anime', 'Anime Live'],
      tabViews: [AnimePage(), LiveAnimePage()],
    );
  }
}
