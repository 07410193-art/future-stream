import 'package:flutter/material.dart';
import '../../models/anime.dart';
import '../../services/anime_service.dart';
import '../molecules/error_view.dart';
import '../organisms/anime_list.dart';

// Screen 1: uses a FutureBuilder.
// A Future is "one answer that arrives later". We ask once, then wait.
class AnimePage extends StatefulWidget {
  const AnimePage({super.key});

  @override
  State<AnimePage> createState() => _AnimePageState();
}

// "with AutomaticKeepAliveClientMixin" tells Flutter to keep this screen in
// memory when you switch tabs. Without it, going to the other tab and back
// would download the list again.
class _AnimePageState extends State<AnimePage>
    with AutomaticKeepAliveClientMixin {
  late Future<List<Anime>> future;

  @override
  bool get wantKeepAlive => true;

  // initState runs ONCE when the screen opens. We start the download here
  // (not inside build), so it does not repeat every time the screen redraws.
  @override
  void initState() {
    super.initState();
    future = fetchTopAnime();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // required when using AutomaticKeepAliveClientMixin

    // FutureBuilder rebuilds itself when the Future finishes.
    // "snapshot" holds the current state: waiting, error, or data.
    return FutureBuilder<List<Anime>>(
      future: future,
      builder: (context, snapshot) {
        // 1. Still waiting: show a spinner.
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }

        // 2. Failed: show the message and a Retry button.
        //    setState makes Flutter redraw, and we start a fresh download.
        if (snapshot.hasError) {
          return ErrorView(
            message: '${snapshot.error}',
            onRetry: () {
              setState(() {
                future = fetchTopAnime();
              });
            },
          );
        }

        // 3. Worked, but the list is empty.
        final list = snapshot.data!;
        if (list.isEmpty) {
          return const Center(child: Text('No anime found.'));
        }

        // 4. Worked and we have data: show the list.
        return AnimeList(items: list);
      },
    );
  }
}
