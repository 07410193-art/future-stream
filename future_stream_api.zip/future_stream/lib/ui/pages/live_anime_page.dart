import 'dart:async';
import 'package:flutter/material.dart';
import '../../models/anime.dart';
import '../../services/anime_service.dart';
import '../molecules/error_view.dart';
import '../organisms/anime_card.dart';

// Screen 2: uses a StreamBuilder.
// A Stream is like a pipe: new values keep arriving over time.
// Here, a new random anime is pushed into the pipe every 5 seconds.
class LiveAnimePage extends StatefulWidget {
  const LiveAnimePage({super.key});

  @override
  State<LiveAnimePage> createState() => _LiveAnimePageState();
}

class _LiveAnimePageState extends State<LiveAnimePage> {
  // The controller is where we put new values into the pipe.
  final controller = StreamController<Anime>();

  // The timer fires every 5 seconds.
  Timer? timer;

  @override
  void initState() {
    super.initState();
    load(); // get the first anime right away
    timer = Timer.periodic(const Duration(seconds: 5), (t) => load());
  }

  // Fetch one anime and push it into the stream.
  // If it fails, we push an ERROR into the stream instead.
  // The stream (and the timer) keep running, so the next try can succeed.
  Future<void> load() async {
    try {
      final anime = await fetchRandomAnime();
      if (!controller.isClosed) controller.add(anime);
    } catch (e) {
      if (!controller.isClosed) controller.addError(e);
    }
  }

  // dispose runs when the screen closes. Always clean up timers and
  // controllers, otherwise they keep running in the background.
  @override
  void dispose() {
    timer?.cancel();
    controller.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // StreamBuilder rebuilds every time something new arrives in the stream.
    return StreamBuilder<Anime>(
      stream: controller.stream,
      builder: (context, snapshot) {
        // 1. The last thing that arrived was an error.
        if (snapshot.hasError) {
          return ErrorView(
            message: '${snapshot.error}\nTrying again in 5 seconds...',
          );
        }

        // 2. Nothing has arrived yet: show a spinner.
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        // 3. We have an anime: show it.
        return AnimeCard(anime: snapshot.data!);
      },
    );
  }
}
