import 'package:flutter/material.dart';

// Atom: the smallest piece. Shows a star and the score.
class ScoreBadge extends StatelessWidget {
  final double? score;
  const ScoreBadge({super.key, this.score});

  @override
  Widget build(BuildContext context) {
    // "score ?? 'N/A'" means: use the score, but if it is null, show N/A.
    return Text(
      '⭐ ${score ?? 'N/A'}',
      style: const TextStyle(fontWeight: FontWeight.bold),
    );
  }
}
