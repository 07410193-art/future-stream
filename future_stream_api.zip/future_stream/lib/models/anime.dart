// A model is a plain Dart class that holds the data we need.
// The API sends JSON (text). fromJson turns that JSON into an Anime object.
//
// A "?" after a type (like String?) means the value is allowed to be null
// (missing). The API does not always send every field, so we plan for that.
class Anime {
  final String title;
  final String? image; // picture URL, may be missing
  final List<String> genres; // e.g. ['Action', 'Drama']
  final int? episodes; // may be null if the show is still airing
  final double? score; // may be null if nobody rated it yet

  Anime({
    required this.title,
    this.image,
    required this.genres,
    this.episodes,
    this.score,
  });

  // json is a Map: a list of key/value pairs, like {'title': 'Naruto', ...}
  factory Anime.fromJson(Map<String, dynamic> json) {
    // 1. Title. If it is missing, use 'Untitled'.
    String title = json['title'] ?? 'Untitled';

    // 2. Image. It sits deeper inside: images -> jpg -> image_url.
    //    We check each step so we never crash on a missing piece.
    String? image;
    final images = json['images'];
    if (images != null && images['jpg'] != null) {
      image = images['jpg']['image_url'];
    }

    // 3. Genres. The API sends a list of objects like {'name': 'Action'}.
    //    We loop through and keep only the names.
    List<String> genres = [];
    final genreList = json['genres'];
    if (genreList != null) {
      for (final g in genreList) {
        genres.add('${g['name']}');
      }
    }

    // 4. Episodes. Only accept it if it is really a whole number.
    int? episodes;
    final episodeValue = json['episodes'];
    if (episodeValue is int) {
      episodes = episodeValue;
    }

    // 5. Score. Could arrive as 8 or 8.5, so turn any number into a double.
    double? score;
    final scoreValue = json['score'];
    if (scoreValue is num) {
      score = scoreValue.toDouble();
    }

    return Anime(
      title: title,
      image: image,
      genres: genres,
      episodes: episodes,
      score: score,
    );
  }
}
