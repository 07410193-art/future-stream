import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/anime.dart';

// The service talks to the internet. The screens never call the API
// directly; they just call the two functions at the bottom of this file.
//
// Tenrai API: free, no API key needed.
// (The old Jikan public API was shut down on October 1, 2026.)
const _base = 'https://api.tenrai.org/v1';

// Downloads one URL and returns the "data" part of the JSON.
// If anything goes wrong, it throws a short message (a String) that the
// screens can show to the user.
Future<dynamic> _get(String path) async {
  try {
    // Build the full address, e.g. https://api.tenrai.org/v1/top/anime
    final url = Uri.parse('$_base$path');

    // Ask the server. Give up after 15 seconds (timeout).
    final response = await http.get(url).timeout(const Duration(seconds: 15));

    // Check the status code. 200 means "OK". Anything else is a problem.
    if (response.statusCode == 429) {
      throw 'Too many requests. Please wait a moment.';
    }
    if (response.statusCode != 200) {
      throw 'Server error (${response.statusCode})';
    }

    // Turn the text into Dart data and return the "data" part.
    final body = jsonDecode(response.body);
    return body['data'];
  } on TimeoutException {
    // The server took too long.
    throw 'Request timed out. Try again.';
  } on String {
    // This is one of our own messages from above. Pass it along.
    rethrow;
  } catch (e) {
    // Anything else, like no internet (airplane mode).
    // debugPrint shows the real reason in the Debug Console.
    debugPrint('Anime error: $e');
    throw 'Could not load. Check your internet connection.';
  }
}

// Screen 1: get the list of top anime.
Future<List<Anime>> fetchTopAnime() async {
  final data = await _get('/top/anime?sfw-strict&limit=20');

  // data is a list of JSON items. Turn each one into an Anime object.
  List<Anime> result = [];
  for (final item in data) {
    result.add(Anime.fromJson(item));
  }
  return result;
}

// Screen 2: get one random anime (a different one every time).
Future<Anime> fetchRandomAnime() async {
  final data = await _get('/random/anime?sfw-strict');
  return Anime.fromJson(data);
}
